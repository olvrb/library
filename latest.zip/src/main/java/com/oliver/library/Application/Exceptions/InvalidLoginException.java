package com.oliver.library.Application.Exceptions;

import javax.naming.AuthenticationException;

public class InvalidLoginException extends AuthenticationException { }
