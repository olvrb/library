package com.oliver.library.Application.Exceptions;

public class RentalObjectRentedException extends Exception {
    public RentalObjectRentedException(String message) {
        super(message);
    }

}
