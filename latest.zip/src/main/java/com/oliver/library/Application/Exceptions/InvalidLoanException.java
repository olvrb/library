package com.oliver.library.Application.Exceptions;

public class InvalidLoanException extends Exception {
    public InvalidLoanException(String message) {
        super(message);
    }
}
